<div class="row">
    <div class="col-md-12 text-center">
        <img src="assets/img/Logo1.png" alt="Gambar Sistem" class="img-responsive center-block" style="margin-top: 30px;">
    </div>
</div>
<body bgcolor="Pink">
<h1><p align="center">
<font color="maroon">
   	Selamat Datang di Sistem Pendukung Keputusan <br>
	Penentuan Penerima Beasiswa di Perbanas Institute Jakarta <br>
	Menggunakan Metode Simple Additive Weighting (SAW)
</h1> 
</b>
</p>
</font>
<footer class="text-center" style="margin-top: 50px; padding: 20px 0; background-color: #f8f8f8; border-top: 1px solid #e7e7e7;">
    <div class="container">
        <p class="text-muted">Sistem Pendukung Keputusan Beasiswa &copy; 2025 - Perbanas Institute Jakarta</p>
    </div>
</footer>
